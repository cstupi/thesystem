const axios = require('axios')
const AWS = require('aws-sdk')

exports.handler = setHighLow

async function setHighLow() {
  const db = new AWS.DynamoDB.DocumentClient();
  const keyParams = {
    TableName: 'Keys',
    Key: {
      id: 'xignite'
    }
  }
  const xToken = dbRes.Item.value
  const res = await axios.get(`https://alerts.xignite.com/xAlerts.json/SearchAlerts?Pattern=cstupi.com&_token=${xToken}`)
  const data = res.data
  for(let a of data){
    axios.get(`https://alerts.xignite.com/xAlerts.json/DeleteAlerts?AlertIdentifiers=${a.AlertIdentifier}&_token=${xToken}`)
  }
}