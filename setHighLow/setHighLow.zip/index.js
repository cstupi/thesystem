const axios = require('axios')
const {uuid} = require('uuidv4')
const AWS = require('aws-sdk')

exports.handler = setHighLow

async function setHighLow() {
  const db = new AWS.DynamoDB.DocumentClient();
  const keyParams = {
    TableName: 'Keys',
    Key: {
      id: 'xignite'
    }
  }
  xToken = await db.get(keyParams).promise()
  const res = await axios.get(`https://globalrealtime.xignite.com/v3/xGlobalRealTime.json/GetBar?IdentifierType=Symbol&Identifier=SPY&EndTime=${new Date()}&Precision=Minutes&Period=15&_token=${xToken['value']}`)
  if(!res.data) 
    return
  const data = { symbol: data.Identifier, high: data.Bar.High, low: data.Bar.Low }
  
  const highParam = {
    TableName: 'Alerts',
    Item: {
      id: uuid(),
      date: new Date(),
      condition: `Last>=${data.Bar.High}`
    }
  }
  const lowParam = {
    TableName: 'Alerts',
    Item: {
      id: uuid(),
      date: new Date(),
      condition: `Last<=${data.Bar.Low}`
    }
  }
  db.put(highParam)
  db.put(lowParam)
  const hook = await db.get({ TableName: 'Keys', Key: { id: 'slackHook' }}).promise()
  await axios.post(hook['value'],{ 
    'text': `Symbol: ${data.symbol} Opening 15min High: ${data.high} Opening 15min Low: ${data.low}`})
  return
}