const axios = require('axios')
const AWS = require('aws-sdk')

exports.handler = triggerSystemAlertReset

async function triggerSystemAlertReset(event, context, callback) {
    if(!event.queryStringParameters) {
      throw new Error('Missing parameters')
    }
    console.log('Query params: ', event.queryStringParameters)
    const systemid = event.queryStringParameters.SystemId
    const symbol = event.queryStringParameters.Symbol
    const direction = event.queryStringParameters.Direction
    if(!systemid || !symbol || !direction){
      throw new Error(`Missing query parameter`)
    }
    const db = new AWS.DynamoDB.DocumentClient()
    const alertRes = await db.get({TableName: 'Alerts', Key: { id: systemid }}).promise()
    const xToken = (await db.get({ TableName: 'Keys', Key: {id: 'xignite'}}).promise()).Item.value
    
    const quoteRes = await axios.get(`https://globalrealtime.xignite.com/v3/xGlobalRealTime.json/GetGlobalExtendedQuote?IdentifierType=Symbol&Identifier=${symbol}&_token=${xToken}`)
    const price = quoteRes.data.Last
    const hookRes = await db.get({ TableName: 'Keys', Key: { id: 'slackHook' }}).promise()
    const hook = hookRes.Item
    
    await axios.post(hook['value'],{ 
    'text': `Symbol: ${symbol} for has triggered a ${direction} event with price of ${quoteRes.data["Last"]}`})
    
    return {
      statusCode: 204   }
}