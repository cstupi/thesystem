const axios = require('axios')
const { uuid } = require('uuidv4')
const AWS = require('aws-sdk')

exports.handler = highTriggered

async function highTriggered(event, context, callback) {
    if(!event.queryStringParameters)
      throw new Error('Missing parameters')
    console.log(event.queryStringParameters)
    return
}